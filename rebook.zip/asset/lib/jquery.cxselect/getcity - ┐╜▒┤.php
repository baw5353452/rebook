<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>test</title>
</head>
<body>
<p>省份：<?=$_POST['province']?></p>
<p>城市：<?=$_POST['city']?></p>
<p>地区：<?=$_POST['area']?></p>
</body>
</html>