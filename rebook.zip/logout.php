<?php
setcookie('user_id','',time()-1);
echo "<script>location.href='index.php';</script>";
?>